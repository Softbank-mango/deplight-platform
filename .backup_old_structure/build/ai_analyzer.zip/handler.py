import json
import os
import base64
import hashlib
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional
import boto3
import urllib.request
import urllib.parse
import urllib.error

# Initialize AWS clients
ssm = boto3.client("ssm")
dynamodb = boto3.resource("dynamodb")
s3 = boto3.client("s3")


def _get_secret_from_ssm(param_name: str) -> Optional[str]:
    """Retrieve secret from SSM Parameter Store"""
    try:
        resp = ssm.get_parameter(Name=param_name, WithDecryption=True)
        return resp["Parameter"]["Value"]
    except Exception as e:
        print(f"Error retrieving SSM parameter {param_name}: {e}")
        return None


def _call_gpt5(api_key: str, base_url: str, model: str, messages: List[Dict],
               temperature: float = 0.7, max_tokens: int = 4000) -> Dict:
    """Call GPT-5 via Letsur Gateway"""
    url = f"{base_url}/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }

    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens
    }

    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers=headers,
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=300) as response:
            result = json.loads(response.read().decode("utf-8"))
            return result
    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8")
        print(f"HTTP Error calling GPT-5: {e.code} - {error_body}")
        raise
    except Exception as e:
        print(f"Error calling GPT-5: {e}")
        raise


def _detect_project_type(files: List[str], readme_content: str) -> Dict[str, Any]:
    """Detect project type, language, framework from file list and README"""

    project_info = {
        "languages": [],
        "frameworks": [],
        "build_tools": [],
        "package_managers": [],
        "recommended_runtime": None
    }

    # Detect by file presence
    file_patterns = {
        "package.json": {"lang": "JavaScript/TypeScript", "runtime": "Node.js", "pkg_mgr": "npm/yarn"},
        "requirements.txt": {"lang": "Python", "runtime": "Python 3.11", "pkg_mgr": "pip"},
        "Pipfile": {"lang": "Python", "runtime": "Python 3.11", "pkg_mgr": "pipenv"},
        "poetry.lock": {"lang": "Python", "runtime": "Python 3.11", "pkg_mgr": "poetry"},
        "go.mod": {"lang": "Go", "runtime": "Go 1.21", "pkg_mgr": "go modules"},
        "Cargo.toml": {"lang": "Rust", "runtime": "Rust", "pkg_mgr": "cargo"},
        "pom.xml": {"lang": "Java", "runtime": "Java 17", "build": "Maven"},
        "build.gradle": {"lang": "Java/Kotlin", "runtime": "Java 17", "build": "Gradle"},
        "composer.json": {"lang": "PHP", "runtime": "PHP 8.2", "pkg_mgr": "composer"},
        "Gemfile": {"lang": "Ruby", "runtime": "Ruby 3.2", "pkg_mgr": "bundler"},
    }

    for file in files:
        for pattern, info in file_patterns.items():
            if pattern in file.lower():
                if "lang" in info and info["lang"] not in project_info["languages"]:
                    project_info["languages"].append(info["lang"])
                if "runtime" in info:
                    project_info["recommended_runtime"] = info["runtime"]
                if "pkg_mgr" in info and info["pkg_mgr"] not in project_info["package_managers"]:
                    project_info["package_managers"].append(info["pkg_mgr"])
                if "build" in info and info["build"] not in project_info["build_tools"]:
                    project_info["build_tools"].append(info["build"])

    # Detect frameworks from common files
    if "next.config.js" in files or "next.config.ts" in files:
        project_info["frameworks"].append("Next.js")
    if "nuxt.config.js" in files or "nuxt.config.ts" in files:
        project_info["frameworks"].append("Nuxt.js")
    if "angular.json" in files:
        project_info["frameworks"].append("Angular")
    if "vue.config.js" in files:
        project_info["frameworks"].append("Vue.js")
    if "manage.py" in files:
        project_info["frameworks"].append("Django")
    if any("fastapi" in f.lower() for f in files):
        project_info["frameworks"].append("FastAPI")
    if any("flask" in f.lower() for f in files):
        project_info["frameworks"].append("Flask")
    if any("express" in f.lower() or "app.js" in f.lower() for f in files):
        project_info["frameworks"].append("Express")

    # Check for Dockerfile
    if "Dockerfile" in files or "dockerfile" in files:
        project_info["has_dockerfile"] = True
    else:
        project_info["has_dockerfile"] = False

    return project_info


def _generate_deployment_specs(api_key: str, base_url: str, model: str,
                               project_info: Dict, readme_content: str,
                               file_list: List[str]) -> Dict[str, str]:
    """Generate deployment specifications using GPT-5"""

    system_prompt = """You are an expert DevOps engineer specialized in cloud deployments.
Your task is to analyze a code repository and generate production-ready deployment specifications.

Generate the following files:
1. Dockerfile - Optimized multi-stage build
2. terraform/main.tf - Terraform configuration for AWS ECS Fargate
3. appspec.yaml - CodeDeploy Blue-Green deployment spec
4. buildspec.yaml - AWS CodeBuild specification
5. deployment_recommendations.md - Detailed recommendations

Focus on:
- Security best practices (non-root users, minimal base images)
- Performance optimization (caching, multi-stage builds)
- Cost optimization (right-sizing resources)
- Production readiness (health checks, graceful shutdown)"""

    user_prompt = f"""Analyze this repository and generate deployment specifications:

# Repository Information
Languages: {', '.join(project_info['languages']) if project_info['languages'] else 'Unknown'}
Frameworks: {', '.join(project_info['frameworks']) if project_info['frameworks'] else 'None detected'}
Package Managers: {', '.join(project_info['package_managers']) if project_info['package_managers'] else 'Unknown'}
Build Tools: {', '.join(project_info['build_tools']) if project_info['build_tools'] else 'None'}
Recommended Runtime: {project_info['recommended_runtime'] or 'Unknown'}
Has Dockerfile: {project_info['has_dockerfile']}

# README Content
```
{readme_content[:2000]}  # First 2000 chars
```

# File Structure (sample)
```
{chr(10).join(file_list[:50])}  # First 50 files
```

Generate complete, production-ready specifications. Use YAML/HCL syntax correctly.
For ECS Fargate, assume:
- VPC and subnets exist
- ALB exists with Blue-Green target groups
- ECR repository exists
- Container port: 8000 (adjust if needed based on framework)"""

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}
    ]

    print("Calling GPT-5 for deployment spec generation...")
    result = _call_gpt5(api_key, base_url, model, messages, temperature=0.3, max_tokens=4000)

    # Extract generated content
    content = result["choices"][0]["message"]["content"]

    # Parse the response to extract individual files
    # This is a simple parser - in production, use more robust parsing
    specs = {
        "dockerfile": "",
        "terraform_main": "",
        "appspec": "",
        "buildspec": "",
        "recommendations": ""
    }

    # Simple extraction logic (looking for code blocks)
    # In production, you'd want more sophisticated parsing
    if "```dockerfile" in content.lower():
        start = content.lower().find("```dockerfile") + len("```dockerfile")
        end = content.find("```", start)
        specs["dockerfile"] = content[start:end].strip()

    if "```hcl" in content.lower() or "```terraform" in content.lower():
        start_marker = "```hcl" if "```hcl" in content.lower() else "```terraform"
        start = content.lower().find(start_marker) + len(start_marker)
        end = content.find("```", start)
        specs["terraform_main"] = content[start:end].strip()

    if "```yaml" in content.lower():
        # Find appspec.yaml
        yaml_start = content.lower().find("appspec.yaml")
        if yaml_start > 0:
            start = content.find("```yaml", yaml_start) + len("```yaml")
            end = content.find("```", start)
            specs["appspec"] = content[start:end].strip()

        # Find buildspec.yaml
        buildspec_start = content.lower().find("buildspec.yaml")
        if buildspec_start > 0:
            start = content.find("```yaml", buildspec_start) + len("```yaml")
            end = content.find("```", start)
            specs["buildspec"] = content[start:end].strip()

    specs["recommendations"] = content  # Full response as recommendations

    return specs


def _store_analysis_results(table_name: str, analysis_id: str, repository: str,
                            commit_sha: str, project_info: Dict, specs: Dict,
                            recommendation: str) -> None:
    """Store analysis results in DynamoDB"""
    table = dynamodb.Table(table_name)

    item = {
        "analysis_id": analysis_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "repository": repository,
        "commit_sha": commit_sha,
        "project_info": json.dumps(project_info),
        "specs": json.dumps(specs),
        "recommendation": recommendation,
        "ttl": int(datetime.now(timezone.utc).timestamp()) + 2592000  # 30 days
    }

    try:
        table.put_item(Item=item)
        print(f"Stored analysis results: {analysis_id}")
    except Exception as e:
        print(f"Error storing analysis results: {e}")


def _upload_specs_to_s3(bucket: str, analysis_id: str, specs: Dict) -> Dict[str, str]:
    """Upload generated specs to S3 and return URLs"""
    urls = {}

    for spec_name, content in specs.items():
        if not content:
            continue

        key = f"analysis/{analysis_id}/{spec_name}"

        try:
            s3.put_object(
                Bucket=bucket,
                Key=key,
                Body=content.encode("utf-8"),
                ContentType="text/plain"
            )
            urls[spec_name] = f"s3://{bucket}/{key}"
            print(f"Uploaded {spec_name} to S3: {urls[spec_name]}")
        except Exception as e:
            print(f"Error uploading {spec_name} to S3: {e}")

    return urls


def lambda_handler(event, context):
    """
    Main Lambda handler for AI Code Analyzer

    Event format:
    {
        "repository": "owner/repo",
        "commit_sha": "abc123",
        "branch": "main",
        "pusher": "username",
        "timestamp": "2025-01-01T00:00:00Z"
    }
    """
    print("AI Analyzer invoked")
    print("Event:", json.dumps(event))

    # Extract environment variables
    letsur_key = _get_secret_from_ssm(os.getenv("LETSUR_API_KEY_PARAM", "/delightful/letsur/api_key"))
    base_url = os.getenv("LETSUR_BASE_URL", "https://gateway.letsur.ai/v1")
    model = os.getenv("LETSUR_MODEL", "gpt-5")
    ai_analysis_table = os.getenv("AI_ANALYSIS_TABLE", "delightful-deploy-ai-analysis")
    s3_bucket = os.getenv("S3_BUCKET", "delightful-deploy-artifacts")

    if not letsur_key:
        print("ERROR: Letsur API key not found in SSM")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "API key not configured"})
        }

    # Generate analysis ID
    analysis_id = hashlib.sha256(
        f"{event.get('repository', 'unknown')}-{event.get('commit_sha', 'unknown')}-{datetime.now(timezone.utc).isoformat()}".encode()
    ).hexdigest()[:16]

    try:
        # Step 1: Extract repository information from event
        repository = event.get("repository", "unknown/repo")
        commit_sha = event.get("commit_sha", "unknown")
        branch = event.get("branch", "main")

        print(f"Analyzing repository: {repository} @ {commit_sha}")

        # Step 2: Simulate fetching repository files
        # In production, you'd use GitHub API or AWS CodeCommit API
        # For now, we'll create a mock structure
        file_list = [
            "README.md",
            "package.json",
            "src/index.ts",
            "src/app.ts",
            "tsconfig.json",
            ".gitignore",
            "Dockerfile"
        ]

        readme_content = """# Demo Application

This is a demo Node.js application using Express and TypeScript.

## Features
- REST API endpoints
- Health check
- Docker support

## Running locally
```
npm install
npm start
```

The server runs on port 8000."""

        # Step 3: Detect project type
        print("Detecting project type...")
        project_info = _detect_project_type(file_list, readme_content)
        print(f"Project info: {json.dumps(project_info)}")

        # Step 4: Generate deployment specs with GPT-5
        print("Generating deployment specifications...")
        specs = _generate_deployment_specs(
            letsur_key, base_url, model,
            project_info, readme_content, file_list
        )

        # Step 5: Generate recommendation summary
        recommendation = "auto-apply" if project_info["has_dockerfile"] else "manual-review"

        if not specs["dockerfile"]:
            recommendation = "manual-review"
            recommendation_text = "No Dockerfile detected. Manual review recommended for deployment configuration."
        elif len(project_info["frameworks"]) == 0:
            recommendation = "manual-review"
            recommendation_text = "Framework not clearly detected. Please review generated specs carefully."
        else:
            recommendation = "auto-apply"
            recommendation_text = f"Detected {', '.join(project_info['frameworks'])}. Specs generated and ready for deployment."

        # Step 6: Store analysis results
        print("Storing analysis results...")
        _store_analysis_results(
            ai_analysis_table, analysis_id, repository, commit_sha,
            project_info, specs, recommendation
        )

        # Step 7: Upload specs to S3
        print("Uploading specs to S3...")
        spec_urls = _upload_specs_to_s3(s3_bucket, analysis_id, specs)

        # Step 8: Return results
        result = {
            "analysis_id": analysis_id,
            "repository": repository,
            "commit_sha": commit_sha,
            "branch": branch,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "project_info": project_info,
            "recommendation": recommendation,
            "recommendation_text": recommendation_text,
            "spec_urls": spec_urls,
            "status": "success"
        }

        print("Analysis complete:", json.dumps(result, default=str))

        return {
            "statusCode": 200,
            "body": json.dumps(result, default=str)
        }

    except Exception as e:
        print(f"ERROR during analysis: {e}")
        import traceback
        traceback.print_exc()

        return {
            "statusCode": 500,
            "body": json.dumps({
                "analysis_id": analysis_id,
                "status": "error",
                "error": str(e)
            })
        }
