"""
Project analyzers using GPT-5
"""
